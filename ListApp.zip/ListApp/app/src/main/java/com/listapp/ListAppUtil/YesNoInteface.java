package com.listapp.ListAppUtil;

/**
 * Created by syscraft on 7/21/2017.
 */

public interface YesNoInteface {

    void isNoYes(boolean b);
}
