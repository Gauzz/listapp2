package com.listapp.API_Utility.AsyncTask_Utility;

/**
 * Created by Syacraft on 01-Oct-16.
 */
public interface UrlConfig {

     public static String BASE_URL = "http://listapp.in/dev/api/Login/";

     public static String signUp = BASE_URL+"signUp";
     public static String login = BASE_URL+"login";
     public static String checkDeviceReg = BASE_URL+"checkDeviceReg";
     public static String StateCity = BASE_URL+"StateCity";
     public static String getTermsCondition = BASE_URL+"getTermsCondition";

     String OTP_VERIFY = BASE_URL+"otpVerify";
     String RESEND_OTP = BASE_URL+"resendOTP";

}

