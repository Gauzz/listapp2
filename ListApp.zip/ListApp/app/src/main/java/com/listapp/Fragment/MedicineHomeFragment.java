package com.listapp.Fragment;

/**
 * Created by Nivesh on 6/22/2017.
 */

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import com.listapp.Activity.MedicineSearchActivity;
import com.listapp.R;

public class MedicineHomeFragment extends Fragment{

    private static FrameLayout fragmentView;
    private static RelativeLayout parentView;
    private LinearLayout search;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, null);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        MedicineSearchActivity.heading.setText("HOME");

        fragmentView = (FrameLayout) view.findViewById(R.id.fragmentView);
        parentView = (RelativeLayout) view.findViewById(R.id.parentView);
        search = (LinearLayout) view.findViewById(R.id.search);

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                hideParentView();
                getFragmentManager().beginTransaction().replace(R.id.fragmentView,new MedicineSearchFragment(),"").addToBackStack("").commit();
            }
        });
        hideFragmentView();
        MedicineSearchActivity.heading.setVisibility(View.VISIBLE);
        MedicineSearchActivity.searchView.setVisibility(View.GONE);
        MedicineSearchActivity.backButton.setVisibility(View.GONE);
        MedicineSearchActivity.whichScreen = 1;
        MedicineSearchActivity.search.setText("");
    }

    public static void hideFragmentView()
    {
        parentView.setVisibility(View.VISIBLE);
        fragmentView.setVisibility(View.GONE);
        MedicineSearchActivity.search.setText("");
        MedicineSearchActivity.heading.setVisibility(View.VISIBLE);
        MedicineSearchActivity.searchView.setVisibility(View.GONE);
        MedicineSearchActivity.backButton.setVisibility(View.GONE);
    }

    private void hideParentView()
    {
        parentView.setVisibility(View.GONE);
        fragmentView.setVisibility(View.VISIBLE);
    }
}

