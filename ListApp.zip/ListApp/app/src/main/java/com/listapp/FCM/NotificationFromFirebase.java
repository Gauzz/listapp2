package com.listapp.FCM;

import android.app.ActivityManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.ContextCompat;
//import android.support.v7.app.NotificationCompat;
import android.util.Log;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.listapp.Activity.NotificationActivity;
import com.listapp.Activity.SplashActivity;
import com.listapp.Activity.UpdateAppActivity;
import com.listapp.ListAppUtil.PreferenceConnector;
import com.listapp.R;

import java.util.List;
import java.util.Map;

/**
 * Created by Nivesh on 6/12/2017.
 */

public class NotificationFromFirebase extends FirebaseMessagingService {

    private String title;
    private String message;
    private String userID;
    private String date, time;
    private String id;
    private String type;

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);
        try {
            Map<String, String> params = remoteMessage.getData();
            title = params.get("alert");
            message = params.get("message");
            userID = params.get("notification_user_id");
            date = params.get("date");
            time = params.get("time");
            id = params.get("notification_id");
            type = params.get("notification_type");

            if (id != null && !id.equals(PreferenceConnector.readString(getApplicationContext(), id, ""))) {
                PreferenceConnector.writeString(getApplicationContext(), id, id);
                Intent intent = null;
                intent = new Intent(this, NotificationActivity.class);
                int i = PreferenceConnector.readInteger(this, "notification_", 1);
                if (i == 1) {
                    i += 1;
                    PreferenceConnector.writeInteger(this, "notification_", i);
                } else {
                    i += 1;
                    PreferenceConnector.writeInteger(this, "notification_", i);
                }
                intent.putExtra("date", date);
                intent.putExtra("time", time);
                intent.putExtra("msg", message);
                intent.putExtra("title", title);
                intent.putExtra("notification_id", id);
                intent.putExtra("type", type);
                PendingIntent pendingIntent = PendingIntent.getActivity
                        (this, 0, intent, PendingIntent.FLAG_ONE_SHOT);
                Uri defaultSoundUri = null;
                try {
                    defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                NotificationCompat.Builder builder = new NotificationCompat
                        .Builder(getApplicationContext());

                builder.setContentTitle(title + "")
                        .setContentText(message + "")
                        .setAutoCancel(true)
                        .setSound(defaultSoundUri)
                        .setContentIntent(pendingIntent);

                if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    builder.setSmallIcon(R.drawable.notification);
                    builder.setColor(ContextCompat.getColor(getApplicationContext(), R.color.primaryYellow));
                } else {
                    builder.setSmallIcon(R.drawable.app_icon);
                }

                NotificationManager notificationManager = (NotificationManager)
                        getSystemService(Context.NOTIFICATION_SERVICE);
                notificationManager.notify(i, builder.build());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private boolean isAppIsInBackground() {
        boolean isInBackground = true;
        ActivityManager am = (ActivityManager) this.getSystemService(Context.ACTIVITY_SERVICE);
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT_WATCH) {
            List<ActivityManager.RunningAppProcessInfo> runningProcesses = am.getRunningAppProcesses();
            for (ActivityManager.RunningAppProcessInfo processInfo : runningProcesses) {
                if (processInfo.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                    for (String activeProcess : processInfo.pkgList) {
                        if (activeProcess.equals(this.getPackageName())) {
                            isInBackground = false;
                        }
                    }
                }
            }
        } else {
            List<ActivityManager.RunningTaskInfo> taskInfo = am.getRunningTasks(1);
            ComponentName componentInfo = taskInfo.get(0).topActivity;
            if (componentInfo.getPackageName().equals(this.getPackageName())) {
                isInBackground = false;
            }
        }
        return isInBackground;
    }
}

