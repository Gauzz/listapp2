package com.listapp.Receiver;

/**
 * Created by syscraft on 8/2/2017.
 */

public interface SmsListener {

    public void messageReceived(String messageText);
}
