package com.listapp.Fragment;

/**
 * Created by syscraft on 7/1/2017.
 */

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.listapp.Activity.CompanySearchActivity;
import com.listapp.R;

public class CompanyHomeFragment extends Fragment {

    public static FrameLayout fragmentView;
    public static RelativeLayout parentView;
    private LinearLayout search;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_search_company, null);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        fragmentView = (FrameLayout) view.findViewById(R.id.fragmentView);
        parentView = (RelativeLayout) view.findViewById(R.id.parentView);
        search = (LinearLayout) view.findViewById(R.id.search);
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFragmentView();
            }
        });
        CompanySearchActivity.heading.setVisibility(View.VISIBLE);
        CompanySearchActivity.searchView.setVisibility(View.GONE);
        CompanySearchActivity.backButton.setVisibility(View.GONE);
    }

    public static void hideFragment() {
        fragmentView.setVisibility(View.GONE);
        parentView.setVisibility(View.VISIBLE);
        CompanySearchActivity.heading.setVisibility(View.VISIBLE);
        CompanySearchActivity.searchView.setVisibility(View.GONE);
        CompanySearchActivity.backButton.setVisibility(View.GONE);
    }

    private void showFragmentView() {
        fragmentView.setVisibility(View.VISIBLE);
        parentView.setVisibility(View.GONE);
        getFragmentManager().beginTransaction().replace(R.id.fragmentView,new CompanySearchFragment(),"CompanySearchFragment").addToBackStack("CompanySearchFragment").commit();
    }
}
