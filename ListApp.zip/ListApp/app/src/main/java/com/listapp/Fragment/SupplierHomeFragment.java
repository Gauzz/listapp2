package com.listapp.Fragment;

import android.support.v4.app.Fragment;
import android.view.View;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.os.Bundle;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.LinearLayout;

import com.listapp.Activity.SupplierSearchActivity;
import com.listapp.R;

public class SupplierHomeFragment extends Fragment implements View.OnClickListener {

    private static FrameLayout fragmentView;
    private static RelativeLayout parentView;
    private TextView textview1;
    private TextView textView2;
    private LinearLayout search;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_search_suppliers, null);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        fragmentView = (FrameLayout) view.findViewById(R.id.fragmentView);
        parentView = (RelativeLayout) view.findViewById(R.id.parentView);
        textview1 = (TextView) view.findViewById(R.id.textview1);
        textView2 = (TextView) view.findViewById(R.id.textView2);
        search = (LinearLayout) view.findViewById(R.id.search);
        search.setOnClickListener(this);
    }

    public static void hideFragmentView()
    {
        fragmentView.setVisibility(View.GONE);
        parentView.setVisibility(View.VISIBLE);
        SupplierSearchActivity.heading.setVisibility(View.VISIBLE);
        SupplierSearchActivity.backButton.setVisibility(View.GONE);
        SupplierSearchActivity.searchView.setVisibility(View.GONE);
        SupplierSearchActivity.toolbarCloseIconView.setVisibility(View.GONE);
        SupplierSearchActivity.search.setText("");
    }

    private void showFragmentView()
    {
        fragmentView.setVisibility(View.VISIBLE);
        parentView.setVisibility(View.GONE);
        getFragmentManager().beginTransaction().replace(R.id.fragmentView,new SupplierSearchFragment(),"").addToBackStack("SupplierSearchFragment").commit();

    }

    @Override
    public void onClick(View v) {

        switch (v.getId())
        {
            case R.id.search:
                showFragmentView();
                break;
        }
    }
}
