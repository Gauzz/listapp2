package com.listapp.API_Utility.AsyncTask_Utility;

public interface ResponseHandler {
    void handleResponse(String response);
}
