package com.listapp.FCM;

import android.util.Log;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;
import com.listapp.ListAppUtil.PreferenceConnector;

/**
 * Created by Nivesh on 6/12/2017.
 */

public class FirebaseInstanceService extends FirebaseInstanceIdService {

    @Override
    public void onTokenRefresh() {
        super.onTokenRefresh();
        String firebase_token = FirebaseInstanceId.getInstance().getToken();
    //    Log.e("<<FirebaseInstanceService>>",firebase_token);
        PreferenceConnector.writeString(this,PreferenceConnector.DEVICE_TOKEN,firebase_token);
    }
}
