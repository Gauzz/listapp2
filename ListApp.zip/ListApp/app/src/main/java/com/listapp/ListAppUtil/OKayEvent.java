package com.listapp.ListAppUtil;

/**
 * Created by syscraft on 7/24/2017.
 */

public interface OKayEvent {

    void okayEvent(boolean b);
}
